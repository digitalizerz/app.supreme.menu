<?php

return [

    'name'              => 'Timezone',
    'description'       => 'This is my awesome module',

];