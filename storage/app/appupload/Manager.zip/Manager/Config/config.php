<?php

return [
    'name' => 'Manager'
];
