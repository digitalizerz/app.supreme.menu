<?php

return [

    'name'              => 'Manager',
    'description'       => 'This is my awesome module',

];