<?php

return [

    'name'              => 'Vendorlinks',
    'description'       => 'This is my awesome module',

];