<?php

return [
    'name' => 'Deliveryqr'
];
