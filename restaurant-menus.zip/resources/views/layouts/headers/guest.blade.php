<!-- On  Mobile show just emty space -->
<div class="header y py-5 py-lg-8 mb-6  d-block d-md-block d-lg-none d-lx-none">
</div>

<!-- On Bigger screens show logo -->
<div class="header y py-5 py-lg-8  d-none d-md-none d-lg-block d-lx-block ">
    <div class="container">
        <div class="header-body text-center mb-1">
            <div class="row justify-content-center">
                <a class="navbar-brand" href="/">
                    
                    <img src="{{ config('global.site_logo') }}" width="300" class="thumbnail" alt="...">
                </a>
            </div>
        </div>
    </div>
    
</div>